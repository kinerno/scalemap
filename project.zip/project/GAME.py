import pygame as pg 
import sys
from characters import *
from scalemap import *
import threading
import socket
chonmap = int(input())
pg.init()
sc = pg.display.set_mode((1800,900),pg.RESIZABLE)
tm=0
stt = "STANDING"
fy=False
clock = pg.time.Clock()
stage=2
hp=500
font = pg.font.SysFont('arial',150)
nhal = {"ryu":RYU,"chunli":CHUNLI,"pikachu":PIKACHU}
s2 = pg.Rect(1700,490,50,500)
rx=ry=0
class MAP:
    def __init__(self,tm,nfrs,m):
        self.tm = int(tm)
        self.nfrs = nfrs
        self.m=m
    def vemap(self):
        sc.fill((0,0,0))
        if int(tm-self.tm)//2>=self.nfrs: self.tm = int(tm)
        bg1 = pg.transform.scale(pg.image.load(f'MAP/m{self.m}/({int(tm-self.tm)//2}).gif'),(1800,900))
        sc.blit(bg1,(0,0))
class animate:
    def __init__(self, nfrs,tm,name,stt):
        self.nfrs = nfrs
        self.tm=int(tm)
        self.name = name
        self.stt = stt
    def danhdau(self):
        if int(tm) - self.tm>=self.nfrs[stt][0]:
            self.tm = int(tm)
    def hoat_anh(self):
        global stt, y, rx,ry
        if stt == "STANDING":
            anh=pg.transform.flip(pg.transform.scale(pg.image.load("nhanvat/"+self.name+"_animations/"+stt+"/frame"+"("+str(int(tm)-self.tm)+")"+".gif"),(self.nfrs[stt][1]*scale,self.nfrs[stt][2]*scale)),fx,fy)
        if stt == "JUMPING":
            anh=pg.transform.flip(pg.transform.scale(pg.image.load("nhanvat/"+self.name+"_animations/"+stt+"/frame "+"("+str(int(tm)-self.tm)+")"+".gif"),(self.nfrs[stt][1]*scale,self.nfrs[stt][2]*scale)),fx,fy)
            ry=self.nfrs[stt][5]
            if not fx:
                rx=self.nfrs[stt][6]
            if int(tm)-self.tm in range(self.nfrs[stt][3],self.nfrs[stt][4]):
                y-=self.nfrs[stt][7]
            if int(tm)-self.tm >= self.nfrs[stt][4]:
                y+=self.nfrs[stt][7]-2
            if int(tm)-self.tm==self.nfrs[stt][0]-1:
                stt = "STANDING"
                self.tm = int(tm)
        if stt == "MOVING":
            anh=pg.transform.flip(pg.transform.scale(pg.image.load("nhanvat/"+self.name+"_animations/"+stt+"/frame "+"("+str(int(tm)-self.tm)+")"+".gif"),(self.nfrs[stt][1]*scale,self.nfrs[stt][2]*scale)),fx,fy)
            rx=-5
        if stt == "KICK":
            anh=pg.transform.flip(pg.transform.scale(pg.image.load("nhanvat/"+self.name+"_animations/"+stt+"/frame"+"("+str(int(tm)-self.tm)+")"+".gif"),(self.nfrs[stt][1]*scale,self.nfrs[stt][2]*scale)),fx,fy); ry=self.nfrs[stt][3]
            if fx:rx=self.nfrs[stt][4]
            if int(tm)-self.tm>=self.nfrs[stt][0]-1:
                stt = "STANDING"
                self.tm = int(tm)
        if stt == "PUNCH":
            if int(tm)-self.tm in range(self.nfrs[stt][1]):
                anh=pg.transform.flip(pg.transform.scale(pg.image.load("nhanvat/"+self.name+"_animations/"+stt+"/frame"+"("+str(int(tm)-self.tm)+")"+".gif"),(self.nfrs[stt][2]*scale,self.nfrs[stt][3]*scale)),fx,fy); ry=self.nfrs[stt][4]
                if fx: rx=self.nfrs[stt][5]
            else:
                anh=pg.transform.flip(pg.transform.scale(pg.image.load("nhanvat/"+self.name+"_animations/"+stt+"/frame"+"("+str(int(tm)-self.tm)+")"+".gif"),(self.nfrs[stt+'1'][0]*scale,self.nfrs[stt+'1'][1]*scale)),fx,fy); ry=self.nfrs[stt+'1'][2]
                if fx:rx=self.nfrs[stt+'1'][3]
            if int(tm)-self.tm>=self.nfrs[stt][0]-1:
                stt = "STANDING"
                self.tm = int(tm) 
        if stt == "RUNNING":
            anh=pg.transform.flip(pg.transform.scale(pg.image.load("nhanvat/"+self.name+"_animations/"+stt+"/frame "+"("+str(int(tm)-self.tm)+")"+".gif"),(self.nfrs[stt][1]*scale,self.nfrs[stt][2]*scale)),fx,fy)
            if not fx: rx=-100
            else: rx=-90
            if int(tm)-self.tm==9: self.tm=int(tm)-4  
        if stt == "HIGHKICK":
            if int(tm)-self.tm not in range(self.nfrs[stt+'1'][0],self.nfrs[stt+'1'][1]):
                anh=pg.transform.flip(pg.transform.scale(pg.image.load("nhanvat/"+self.name+"_animations/"+stt+"/frame"+"("+str(int(tm)-self.tm)+")"+".gif"),(self.nfrs[stt+'1'][2]*scale,self.nfrs[stt+'1'][3]*scale)),fx,fy)
                ry=self.nfrs[stt][2]
            else: anh=pg.transform.flip(pg.transform.scale(pg.image.load("nhanvat/"+self.name+"_animations/"+stt+"/frame"+"("+str(int(tm)-self.tm)+")"+".gif"),(self.nfrs[stt+'1'][4]*scale,self.nfrs[stt+'1'][5]*scale)),fx,fy)
            if int(tm)-self.tm not in range(self.nfrs[stt+'1'][6]):ry=self.nfrs[stt][1]
            else:ry=self.nfrs[stt][4]
            if int(tm)-self.tm in range(self.nfrs[stt+'1'][7],self.nfrs[stt+'1'][8]):ry=self.nfrs[stt][3]
            if not fx:
                rx=-90
            if int(tm)-self.tm in range(self.nfrs[stt+'1'][9],self.nfrs[stt+'1'][10]):
                y-=2
            if int(tm)-self.tm in range(self.nfrs[stt+'1'][11],self.nfrs[stt+'1'][12]):
                y+=3
            if int(tm)-self.tm==self.nfrs[stt][0]-1:
                stt = "STANDING"
                self.tm = int(tm)
        if stt == "LOWKICK":
            anh=pg.transform.flip(pg.transform.scale(pg.image.load("nhanvat/"+self.name+"_animations/"+stt+"/frame"+"("+str(int(tm)-self.tm)+")"+".gif"),(self.nfrs[stt][1]*scale,self.nfrs[stt][2]*scale)),fx,fy)
            ry=80
            if not fx:
                rx=-90
            if int(tm)-self.tm==self.nfrs[stt][0]-1:
                stt = "STANDING"
                self.tm = int(tm)
        sc.blit(anh,(x+rx,y+ry-240))
    def hitbox(self):
        global rx,ry
        pg.draw.rect(sc,(255,0,0),(x+self.nfrs["POS"][0]*scale-35,ry+y-240+self.nfrs["POS"][1]*scale+50,self.nfrs["SIZE"][2],self.nfrs["SIZE"][1]),5)
        if stt in ["KICK","PUNCH","LOWKICK"]:
            app = [x+self.nfrs["POS"][0]*scale+self.nfrs[astt][stt][2]-self.nfrs["SIZE"][0]*self.nfrs[astt][stt][0],x+self.nfrs["POS"][0]*scale+self.nfrs[astt][stt][3]]
            s1 = pg.Rect(app[1-fx],(ry+y-240+self.nfrs["POS"][1]*scale+50)+(self.nfrs[astt][stt][1]*self.nfrs["SIZE"][1])-30,self.nfrs["SIZE"][0]*self.nfrs[astt][stt][0],10)
            pg.draw.rect(sc,(100,100,100),s1,2)
            if s1.colliderect(s2): print(True)
        if stt == "HIGHKICK":
            #print(".........")
            s1 = pg.Rect(x+self.nfrs["POS"][0]*scale+self.nfrs[astt][stt][2]-self.nfrs["SIZE"][0]*self.nfrs[astt][stt][0],(ry+y-240+self.nfrs["POS"][1]*scale+50)+(self.nfrs[astt][stt][1]*self.nfrs["SIZE"][1])-30,self.nfrs["SIZE"][0]*self.nfrs[astt][stt][0],10)
            #s1=pg.Rect(100,100,100,100)
            pg.draw.rect(sc,(100,100,100),s1,3)
            if s1.colliderect(s2): print(True)
jk = input(">>")
hung = animate(nhal[jk],tm,jk,stt)
att = 0
getpr=""
special = False
stamina = 1000
vc_txt=font.render("∞", True, (255,255,255))
RED,GREEN = (255,50,50),(10,255,30)
color = GREEN
font1=pg.font.Font(r'fontchu\BeVietnamPro-MediumItalic.ttf',34)
hung1 = MAP(0,scalemap[chonmap][1],chonmap)
scale1=scalemap[chonmap][0]*1.32
scale = scale1/1.65
xbandau=[200, 1300]
x,y=200,450*(scale1/1.2)
fx = bool(x-200)
def hehe():
    global stt,special,rx,ry
    while stage==2:
        try:   
            hung1.vemap()
            try:
                rx=ry=0
                hung.danhdau()
                hung.hoat_anh()
                hung.hitbox()
            except Exception as e:
                print(e)
                stt = "STANDING"
                hung.danhdau()
                hung.hoat_anh()   
                special = False
            sc.blit(vc_txt,(1700/2,0))
            pg.draw.rect(sc,(200,200,200),s2)
            pg.display.flip()
        except:pass
p1 = threading.Thread(target=hehe, args=())
fhe=True
pg.mixer.music.load(r"soundtrack/s1.mp3")
#pg.mixer.music.play(-1)
while True:
    clock.tick(350)
    if stage==0:
        pg.draw.rect(sc,(250,250,250),(1700/2))
        for ev in pg.event.get():
            if ev.type==pg.QUIT:
                pg.quit()
                sys.exit()
        pg.display.update()
    if stage == 1:
        sc.fill((0,0,0))
        r1 = pg.draw.rect(sc,(0,255,255),(1900/2-120,400,200,75))
        r2 = pg.draw.rect(sc,(0,255,255),(1900/2-120,500,200,75))
        sc.blit(font1.render("tạo phòng",True,(255,255,255)),(1900/2-105,420))
        sc.blit(font1.render("vào phòng",True,(255,255,255)),(1900/2-106,520))        
        for ev in pg.event.get():
            if ev.type==pg.QUIT:
                pg.quit()
                sys.exit()        
    if stage==2:
        #####################################################################
        if fhe: 
            p1.start()
            fhe=False
        for ev in pg.event.get():
            if ev.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if hp>0:
                if ev.type == pg.KEYDOWN:
                    if ev.key == pg.K_UP and stt not in ["JUMPING", "HIGHKICK","bruh"]:
                        att=0
                        if not special:stt = "JUMPING"
                        else:
                            special=False
                            stt="HIGHKICK"
                        hung.tm=int(tm)
                    if ev.key == pg.K_a and stt != "JUMPING":
                        att=0
                        stt = "KICK"
                        hung.tm=int(tm)
                    if ev.key == pg.K_s and stt != "JUMPING":
                        att=0
                        stt = "PUNCH"
                        hung.tm=int(tm)
                    if ev.key == pg.K_RIGHT:
                        getpr = "RIGHT"
                    if ev.key == pg.K_LEFT:
                        getpr = "LEFT"
                    if ev.key == pg.K_q and stamina>2:
                        special = True
                    if ev.key == pg.K_DOWN and stt not in ["HIGHKICK","JUMPING","bruh"]:
                        stt="LOWKICK"
                        att=0
                if ev.type == pg.KEYUP:
                    if ev.key == pg.K_q:
                        special = False            
                    if ev.key in [pg.K_LEFT, pg.K_RIGHT]:
                        getpr=""
                        if stt in ["MOVING", "RUNNING"]:
                            stt = "STANDING"
                            att=0
                            hung.tm = int(tm)
        if att==1 and x<1900-300:
            x+=1
        if att==2 and x>0:
            x-=1
        if att==3 and x<1900-300:x+=3
        if att==4 and x>0:x-=3
        if stt not in ["JUMPING","KICK","PUNCH","HIGHKICK","LOWKICK"]:
            if not special:
                if getpr == "RIGHT":
                    stt = "MOVING"
                    att=1
                    fx=False
                if getpr == "LEFT":
                    stt = "MOVING"
                    att=2
                    fx=True
            else:
                if getpr == "RIGHT":
                    stamina-=5
                    stt = "RUNNING"
                    att=3
                    fx=False
                if getpr == "LEFT":
                    stamina-=5
                    stt = "RUNNING"
                    att=4
                    fx=True
        if stt in ["JUMPING", "HIGHKICK"] and getpr != '':
            if getpr == "RIGHT": att=1
            else: att=2
        elif getpr=='': att=0
        if stamina<1000:stamina+=1
        if stamina<2 and special: special = False
        if (y>450*scale1/1.2 and stt != "LOWKICK") or (stt!="JUMPING" and y<450*scale1/1.2):y=450*scale1/1.2
        tm+=0.05